"""DocScan-Vision: document detection, rectification, enhancement and quality assessment."""

__version__ = "1.0.0"
