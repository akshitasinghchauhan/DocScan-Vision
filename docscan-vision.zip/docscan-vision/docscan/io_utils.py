"""Image I/O, validation and logging helpers."""
import logging
import os
from typing import List

import cv2
import numpy as np

SUPPORTED = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")
log = logging.getLogger("docscan")


class ImageError(Exception):
    """Raised when an image cannot be read or is invalid."""


def setup_logging(log_file: str = "docscan.log", verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    handlers = [logging.StreamHandler(), logging.FileHandler(log_file, encoding="utf-8")]
    logging.basicConfig(level=level, handlers=handlers, force=True,
                        format="%(asctime)s | %(levelname)-7s | %(message)s")


def load_image(path: str) -> np.ndarray:
    if not os.path.isfile(path):
        raise ImageError(f"File not found: {path}")
    if not path.lower().endswith(SUPPORTED):
        raise ImageError(f"Unsupported file type: {path}")
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None or img.size == 0:
        raise ImageError(f"Could not decode image: {path}")
    if min(img.shape[:2]) < 100:
        raise ImageError(f"Image too small (min side must be >= 100 px): {path}")
    return img


def save_image(path: str, img: np.ndarray) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    if not cv2.imwrite(path, img):
        raise ImageError(f"Could not write image: {path}")


def list_images(folder: str) -> List[str]:
    if not os.path.isdir(folder):
        raise ImageError(f"Folder not found: {folder}")
    return sorted(os.path.join(folder, f) for f in os.listdir(folder)
                  if f.lower().endswith(SUPPORTED))
