"""Image-quality feature extraction and skew estimation."""
from typing import Dict

import cv2
import numpy as np

from .preprocess import to_gray

FEATURE_NAMES = ["sharpness", "brightness", "contrast", "edge_density"]


def extract_features(img: np.ndarray) -> Dict[str, float]:
    """Four interpretable quality features from a (rectified) page image."""
    gray = to_gray(img)
    if gray.shape[0] > 600:  # normalise scale so features are size independent
        f = 600 / gray.shape[0]
        gray = cv2.resize(gray, None, fx=f, fy=f, interpolation=cv2.INTER_AREA)
    lap = cv2.Laplacian(gray, cv2.CV_64F).var()
    edges = cv2.Canny(gray, 50, 150)
    return {
        "sharpness": float(np.log1p(lap)),
        "brightness": float(gray.mean()),
        "contrast": float(gray.std()),
        "edge_density": float((edges > 0).mean()),
    }


def feature_vector(img: np.ndarray) -> np.ndarray:
    f = extract_features(img)
    return np.array([f[k] for k in FEATURE_NAMES], dtype=float)


def estimate_skew(img: np.ndarray) -> float:
    """Estimate text skew in degrees using the minimum-area rectangle of dark pixels."""
    gray = to_gray(img)
    bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(bw > 0))
    if len(coords) < 50:
        return 0.0
    angle = cv2.minAreaRect(coords[:, ::-1].astype(np.float32))[-1]
    angle = ((angle + 45) % 90) - 45          # fold into [-45, 45)
    return float(round(angle, 2))
