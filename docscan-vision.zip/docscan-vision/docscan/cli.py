"""Command-line interface: demo | train | scan | analyze."""
import argparse
import json
import os
import sys

from . import __version__
from .classifier import DEFAULT_MODEL, load_model, train
from .io_utils import ImageError, list_images, load_image, log, save_image, setup_logging
from .pipeline import process_file
from .quality import extract_features
from .synthetic import degrade, make_page, make_photo


def cmd_demo(args) -> int:
    import numpy as np
    rng = np.random.default_rng(args.seed)
    labels = ["good", "blurry", "dark", "low_contrast"]
    for i in range(args.count):
        label = labels[i % len(labels)]
        photo, _ = make_photo(rng, degrade(make_page(rng), label, rng))
        path = os.path.join(args.out, f"sample_{i + 1:02d}_{label}.jpg")
        save_image(path, photo)
        log.info("Created %s", path)
    return 0


def cmd_train(args) -> int:
    m = train(args.samples, args.seed, args.model)
    print(json.dumps({k: m[k] for k in ("samples_total", "cv_accuracy_mean", "random_forest_test_accuracy",
                                         "rule_baseline_test_accuracy", "feature_importance")}, indent=2))
    return 0


def cmd_scan(args) -> int:
    model = None if args.no_model else load_model(args.model)
    if model is None and not args.no_model:
        log.warning("No trained model at %s - using rule-based quality check. Run `train` first.", args.model)
    files = list_images(args.input) if os.path.isdir(args.input) else [args.input]
    if not files:
        log.error("No supported images found in %s", args.input)
        return 1
    failed = 0
    for f in files:
        try:
            r = process_file(f, args.output, model=model)
            print(f"{os.path.basename(f)}: quality={r['quality']} document_found={r['document_found']} "
                  f"skew={r['skew_degrees']}")
        except ImageError as exc:
            failed += 1
            log.error("%s", exc)
    return 1 if failed else 0


def cmd_analyze(args) -> int:
    try:
        feats = extract_features(load_image(args.input))
    except ImageError as exc:
        log.error("%s", exc)
        return 1
    print(json.dumps({k: round(v, 3) for k, v in feats.items()}, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="docscan", description="Document scanner & quality analyser (computer vision).")
    p.add_argument("--version", action="version", version=__version__)
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("--log-file", default="docscan.log")
    sub = p.add_subparsers(dest="command", required=True)

    d = sub.add_parser("demo", help="generate synthetic document photos")
    d.add_argument("--out", default="sample_data")
    d.add_argument("--count", type=int, default=8)
    d.add_argument("--seed", type=int, default=7)
    d.set_defaults(func=cmd_demo)

    t = sub.add_parser("train", help="train the quality classifier on synthetic data")
    t.add_argument("--samples", type=int, default=60, help="pages per quality class")
    t.add_argument("--seed", type=int, default=42)
    t.add_argument("--model", default=DEFAULT_MODEL)
    t.set_defaults(func=cmd_train)

    s = sub.add_parser("scan", help="scan an image or a folder of images")
    s.add_argument("--input", required=True)
    s.add_argument("--output", default="output")
    s.add_argument("--model", default=DEFAULT_MODEL)
    s.add_argument("--no-model", action="store_true", help="use rule-based quality check only")
    s.set_defaults(func=cmd_scan)

    a = sub.add_parser("analyze", help="print quality features of one image")
    a.add_argument("--input", required=True)
    a.set_defaults(func=cmd_analyze)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    setup_logging(args.log_file, args.verbose)
    try:
        return args.func(args)
    except (ValueError, ImageError) as exc:
        log.error("%s", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
