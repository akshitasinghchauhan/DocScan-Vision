"""Basic preprocessing: grayscale, smoothing, resizing."""
import cv2
import numpy as np


def to_gray(img: np.ndarray) -> np.ndarray:
    return img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def resize_to_height(img: np.ndarray, height: int):
    """Resize keeping aspect ratio. Returns (resized, scale)."""
    scale = height / img.shape[0]
    out = cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    return out, scale


def smooth(gray: np.ndarray, ksize: int = 5) -> np.ndarray:
    if ksize % 2 == 0:
        ksize += 1
    return cv2.GaussianBlur(gray, (ksize, ksize), 0)
