"""Enhancement: contrast equalisation, denoising, scanner-style binarisation."""
import cv2
import numpy as np

from .config import Config, DEFAULT
from .preprocess import to_gray


def enhance_contrast(img: np.ndarray) -> np.ndarray:
    """CLAHE on the lightness channel (colour preserved)."""
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    if img.ndim == 2:
        return clahe.apply(img)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    return cv2.cvtColor(cv2.merge((clahe.apply(l), a, b)), cv2.COLOR_LAB2BGR)


def denoise(img: np.ndarray) -> np.ndarray:
    if img.ndim == 2:
        return cv2.fastNlMeansDenoising(img, None, 10, 7, 21)
    return cv2.fastNlMeansDenoisingColored(img, None, 7, 7, 7, 21)


def scan_effect(img: np.ndarray, cfg: Config = DEFAULT) -> np.ndarray:
    """Black-and-white 'photocopy' look using adaptive (local) thresholding."""
    gray = to_gray(img)
    block = cfg.adaptive_block if cfg.adaptive_block % 2 == 1 else cfg.adaptive_block + 1
    return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY, block, cfg.adaptive_c)
