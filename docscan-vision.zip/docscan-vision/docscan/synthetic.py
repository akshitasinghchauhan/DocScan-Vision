"""Synthetic data generation: fake document photos and quality-degraded pages.

Using generated data keeps the project fully reproducible (no external dataset
download) while still giving exact ground truth for corners and quality labels.
"""
from typing import List, Tuple

import cv2
import numpy as np

from .config import QUALITY_LABELS

WORDS = ("vision image pixel filter kernel edge contour feature gradient scale "
         "threshold histogram corner perspective homography camera sensor noise "
         "segment region object detect track motion lens focus exposure channel "
         "matrix transform smooth sharpen binary gray colour intensity").split()


def make_page(rng: np.random.Generator, w: int = 600, h: int = 800) -> np.ndarray:
    """Create a flat white page filled with random lines of text."""
    base = int(rng.integers(228, 252))
    page = np.full((h, w, 3), base, dtype=np.uint8)
    scale = float(rng.uniform(0.45, 0.58))
    gap = int(rng.integers(28, 40))
    cv2.putText(page, "Report " + str(int(rng.integers(100, 999))), (40, 60),
                cv2.FONT_HERSHEY_DUPLEX, 1.1, (20, 20, 20), 2, cv2.LINE_AA)
    y = 110
    while y < h - 40:
        line = " ".join(rng.choice(WORDS, size=int(rng.integers(4, 6))))
        cv2.putText(page, line, (40, y), cv2.FONT_HERSHEY_SIMPLEX, scale,
                    (35, 35, 35), 1, cv2.LINE_AA)
        y += gap
    return page


def make_photo(rng: np.random.Generator, page: np.ndarray,
               size: Tuple[int, int] = (1100, 1400)) -> Tuple[np.ndarray, np.ndarray]:
    """Place `page` on a textured desk with a random perspective.

    Returns (photo, ground_truth_corners[tl,tr,br,bl])."""
    cw, ch = size
    desk = np.array([70, 90, 120], dtype=np.float32) + rng.normal(0, 6, (ch, cw, 3))
    desk = np.clip(desk, 0, 255).astype(np.uint8)
    ph, pw = page.shape[:2]
    m = 150
    j = lambda: float(rng.uniform(-60, 60))
    dst = np.array([[m + j(), m + j()], [cw - m + j(), m + j()],
                    [cw - m + j(), ch - m + j()], [m + j(), ch - m + j()]], dtype=np.float32)
    src = np.array([[0, 0], [pw - 1, 0], [pw - 1, ph - 1], [0, ph - 1]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(page, matrix, (cw, ch))
    mask = cv2.warpPerspective(np.full((ph, pw), 255, np.uint8), matrix, (cw, ch))
    photo = np.where(mask[..., None] > 0, warped, desk)
    return photo.astype(np.uint8), dst


def degrade(page: np.ndarray, label: str, rng: np.random.Generator) -> np.ndarray:
    """Apply a degradation matching a quality label."""
    img = page.astype(np.float32)
    if label == "blurry":
        sigma = float(rng.uniform(1.5, 4.5))
        img = cv2.GaussianBlur(img, (0, 0), sigma)
    elif label == "dark":
        img = img * float(rng.uniform(0.25, 0.60))
    elif label == "low_contrast":
        img = 165 + (img - 165) * float(rng.uniform(0.15, 0.50))
    elif label != "good":
        raise ValueError(f"Unknown label: {label}")
    img = img + rng.normal(0, float(rng.uniform(1, 4)), img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)


def generate_quality_dataset(n_per_class: int, seed: int = 42) -> Tuple[List[np.ndarray], List[str]]:
    rng = np.random.default_rng(seed)
    images, labels = [], []
    for label in QUALITY_LABELS:
        for _ in range(n_per_class):
            images.append(degrade(make_page(rng), label, rng))
            labels.append(label)
    return images, labels
