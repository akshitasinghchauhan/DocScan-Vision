"""Quality classifier: Random Forest vs. a hand-written rule baseline."""
import json
import os
from typing import Dict, Tuple

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .config import QUALITY_LABELS
from .io_utils import log
from .quality import feature_vector, FEATURE_NAMES
from .synthetic import generate_quality_dataset

DEFAULT_MODEL = os.path.join("models", "quality_model.joblib")


def rule_based_label(features: np.ndarray) -> str:
    """Simple threshold baseline (what a beginner would write without ML)."""
    sharp, bright, contrast, _ = features
    if bright < 150:
        return "dark"
    if sharp < 5.5:
        return "blurry"
    if contrast < 22:
        return "low_contrast"
    return "good"


def build_model(seed: int = 42):
    return make_pipeline(StandardScaler(),
                         RandomForestClassifier(n_estimators=150, random_state=seed))


def train(n_per_class: int = 60, seed: int = 42, model_path: str = DEFAULT_MODEL) -> Dict:
    """Generate data, train, evaluate on a hold-out set and save the model."""
    if n_per_class < 10:
        raise ValueError("n_per_class must be at least 10")
    log.info("Generating %d synthetic pages per class...", n_per_class)
    images, labels = generate_quality_dataset(n_per_class, seed)
    X = np.array([feature_vector(i) for i in images])
    y = np.array(labels)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, stratify=y, random_state=seed)

    model = build_model(seed)
    cv = cross_val_score(model, X_tr, y_tr, cv=5)
    model.fit(X_tr, y_tr)
    pred = model.predict(X_te)
    base = np.array([rule_based_label(x) for x in X_te])

    metrics = {
        "samples_total": int(len(y)),
        "train_size": int(len(y_tr)), "test_size": int(len(y_te)),
        "cv_accuracy_mean": round(float(cv.mean()), 4),
        "cv_accuracy_std": round(float(cv.std()), 4),
        "random_forest_test_accuracy": round(float(accuracy_score(y_te, pred)), 4),
        "rule_baseline_test_accuracy": round(float(accuracy_score(y_te, base)), 4),
        "labels": QUALITY_LABELS,
        "confusion_matrix": confusion_matrix(y_te, pred, labels=QUALITY_LABELS).tolist(),
        "feature_importance": dict(zip(FEATURE_NAMES,
                                       [round(float(v), 4) for v in model[-1].feature_importances_])),
        "report": classification_report(y_te, pred, labels=QUALITY_LABELS, output_dict=True,
                                        zero_division=0),
    }
    os.makedirs(os.path.dirname(os.path.abspath(model_path)), exist_ok=True)
    joblib.dump(model, model_path)
    with open(os.path.splitext(model_path)[0] + "_metrics.json", "w", encoding="utf-8") as fh:
        json.dump(metrics, fh, indent=2)
    log.info("Model saved to %s (test accuracy %.3f)", model_path, metrics["random_forest_test_accuracy"])
    return metrics


def load_model(model_path: str = DEFAULT_MODEL):
    return joblib.load(model_path) if os.path.isfile(model_path) else None


def predict_quality(img: np.ndarray, model=None) -> Tuple[str, Dict[str, float]]:
    """Return (label, per-class probabilities). Falls back to rules if no model."""
    fv = feature_vector(img)
    if model is None:
        label = rule_based_label(fv)
        return label, {k: (1.0 if k == label else 0.0) for k in QUALITY_LABELS}
    probs = model.predict_proba(fv.reshape(1, -1))[0]
    classes = list(model.classes_)
    return classes[int(np.argmax(probs))], {c: round(float(p), 3) for c, p in zip(classes, probs)}
