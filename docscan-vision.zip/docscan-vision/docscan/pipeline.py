"""End-to-end pipeline tying the modules together."""
import json
import os
from dataclasses import dataclass, field
from typing import Dict, Optional

import numpy as np

from .classifier import predict_quality
from .config import Config, DEFAULT
from .detection import draw_corners, find_document_corners
from .enhance import denoise, enhance_contrast, scan_effect
from .io_utils import load_image, log, save_image
from .quality import estimate_skew, extract_features
from .transform import four_point_transform


@dataclass
class ScanResult:
    corners: np.ndarray
    document_found: bool
    detected_overlay: np.ndarray
    warped: np.ndarray
    enhanced: np.ndarray
    black_white: np.ndarray
    quality_label: str
    quality_probs: Dict[str, float]
    features: Dict[str, float]
    skew_degrees: float
    suggestions: list = field(default_factory=list)


def _suggestions(label: str, found: bool) -> list:
    tips = {"blurry": "Hold the camera steady and refocus before capturing.",
            "dark": "Retake in better lighting or enable flash.",
            "low_contrast": "Avoid glare/shadows; place the page on a darker surface."}
    out = [tips[label]] if label in tips else []
    if not found:
        out.append("Page boundary not detected; place the page fully in frame on a contrasting background.")
    return out


def scan_image(img: np.ndarray, cfg: Config = DEFAULT, model=None) -> ScanResult:
    corners, found = find_document_corners(img, cfg)
    overlay = draw_corners(img, corners)
    warped = four_point_transform(img, corners)
    label, probs = predict_quality(warped, model)
    enhanced = enhance_contrast(denoise(warped))
    return ScanResult(corners, found, overlay, warped, enhanced, scan_effect(enhanced, cfg),
                      label, probs, extract_features(warped), estimate_skew(warped),
                      _suggestions(label, found))


def process_file(path: str, out_dir: str, cfg: Config = DEFAULT, model=None) -> Dict:
    """Scan one image file, write outputs and a JSON report. Returns the report dict."""
    img = load_image(path)
    res = scan_image(img, cfg, model)
    stem = os.path.splitext(os.path.basename(path))[0]
    save_image(os.path.join(out_dir, f"{stem}_1_detected.jpg"), res.detected_overlay)
    save_image(os.path.join(out_dir, f"{stem}_2_rectified.png"), res.warped)
    save_image(os.path.join(out_dir, f"{stem}_3_enhanced.png"), res.enhanced)
    save_image(os.path.join(out_dir, f"{stem}_4_scan_bw.png"), res.black_white)
    report = {
        "input": path,
        "document_found": res.document_found,
        "corners": np.round(res.corners, 1).tolist(),
        "quality": res.quality_label,
        "quality_probabilities": res.quality_probs,
        "features": {k: round(v, 3) for k, v in res.features.items()},
        "skew_degrees": res.skew_degrees,
        "suggestions": res.suggestions,
    }
    with open(os.path.join(out_dir, f"{stem}_report.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    log.info("%s -> found=%s quality=%s", os.path.basename(path), res.document_found, res.quality_label)
    return report
