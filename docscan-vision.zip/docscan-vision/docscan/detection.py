"""Document boundary detection using edges + contour analysis."""
from typing import Tuple

import cv2
import numpy as np

from .config import Config, DEFAULT
from .preprocess import resize_to_height, smooth, to_gray


def order_points(pts: np.ndarray) -> np.ndarray:
    """Order 4 points as top-left, top-right, bottom-right, bottom-left."""
    pts = np.asarray(pts, dtype="float32").reshape(4, 2)
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)],
                     pts[np.argmax(s)], pts[np.argmax(d)]], dtype="float32")


def detect_edges(gray: np.ndarray, cfg: Config = DEFAULT) -> np.ndarray:
    edges = cv2.Canny(smooth(gray, cfg.blur_ksize), cfg.canny_low, cfg.canny_high)
    return cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)


def _candidate_masks(gray: np.ndarray, cfg: Config):
    """Yield edge/binary maps from progressively more robust strategies."""
    yield detect_edges(gray, cfg)                                   # 1. plain Canny
    eq = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(8, 8)).apply(gray)
    yield detect_edges(eq, cfg)                                     # 2. contrast-boosted Canny
    blur = smooth(gray, cfg.blur_ksize)
    _, otsu = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    yield cv2.morphologyEx(otsu, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))  # 3. Otsu region


def find_document_corners(img: np.ndarray, cfg: Config = DEFAULT) -> Tuple[np.ndarray, bool]:
    """Return (corners in original-image coords, found_flag).

    Strategies are tried in order. If none yields a 4-sided contour of sufficient
    size, full-frame corners are returned with found_flag=False so the pipeline
    degrades gracefully instead of failing.
    """
    h, w = img.shape[:2]
    small, scale = resize_to_height(img, cfg.work_height)
    gray = to_gray(small)
    min_area = cfg.min_area_ratio * small.shape[0] * small.shape[1]
    for mask in _candidate_masks(gray, cfg):
        contours, _ = cv2.findContours(mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for c in sorted(contours, key=cv2.contourArea, reverse=True)[:10]:
            hull = cv2.convexHull(c)
            approx = cv2.approxPolyDP(hull, cfg.approx_epsilon * cv2.arcLength(hull, True), True)
            area = cv2.contourArea(approx)
            if len(approx) == 4 and min_area <= area < 0.98 * small.shape[0] * small.shape[1]:
                return order_points(approx.reshape(4, 2) / scale), True
    full = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype="float32")
    return full, False


def draw_corners(img: np.ndarray, corners: np.ndarray) -> np.ndarray:
    out = img.copy()
    pts = corners.astype(int).reshape(-1, 1, 2)
    cv2.polylines(out, [pts], True, (0, 255, 0), max(2, img.shape[1] // 300))
    for p in corners.astype(int):
        cv2.circle(out, (int(p[0]), int(p[1])), max(5, img.shape[1] // 120), (0, 0, 255), -1)
    return out
