"""Central configuration for the pipeline (single place to tune parameters)."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    work_height: int = 800          # image is downscaled to this height for detection
    blur_ksize: int = 5             # Gaussian kernel size (odd)
    canny_low: int = 50
    canny_high: int = 150
    min_area_ratio: float = 0.20    # a document must cover at least this share of the frame
    approx_epsilon: float = 0.02    # contour approximation tolerance (x perimeter)
    adaptive_block: int = 31        # adaptive threshold neighbourhood (odd)
    adaptive_c: int = 12
    random_seed: int = 42


DEFAULT = Config()
QUALITY_LABELS = ["good", "blurry", "dark", "low_contrast"]
