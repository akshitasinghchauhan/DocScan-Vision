"""Geometric transforms: perspective rectification."""
import cv2
import numpy as np

from .detection import order_points


def four_point_transform(img: np.ndarray, corners: np.ndarray) -> np.ndarray:
    """Warp the quadrilateral given by `corners` to a flat, top-down rectangle."""
    tl, tr, br, bl = order_points(corners)
    width = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
    height = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
    width, height = max(width, 1), max(height, 1)
    dst = np.array([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
                   dtype="float32")
    matrix = cv2.getPerspectiveTransform(np.array([tl, tr, br, bl], dtype="float32"), dst)
    return cv2.warpPerspective(img, matrix, (width, height))
