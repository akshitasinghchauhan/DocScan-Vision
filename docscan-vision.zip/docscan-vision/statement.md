# Problem Statement

## Problem
Photos of paper documents taken with a phone are rarely usable as-is: the page is
skewed by perspective, surrounded by background clutter, and often poorly lit, out of
focus or low in contrast. Manual cropping and retouching is slow, and users only
discover a bad capture after it is too late to retake it.

## Scope
DocScan-Vision is a command-line computer-vision tool that:
1. Detects the boundary of a document in a photo (edge detection + contour analysis).
2. Rectifies it to a flat, top-down view (perspective / homography transform).
3. Enhances it (denoising, CLAHE, adaptive thresholding for a "scanner" look).
4. Assesses capture quality (blurry / dark / low-contrast / good) with a classical-feature
   + machine-learning classifier, and reports page skew and retake suggestions.

Out of scope: OCR / text recognition, multi-page PDF assembly, deep-learning detectors,
mobile or GUI front ends.

## Target Users
- Students and office users digitising notes, forms and receipts.
- Developers who need a lightweight, scriptable pre-processing step before OCR.
- Evaluators / instructors who need a reproducible computer-vision demonstration.

## High-Level Features
- Document corner detection with three fallback strategies and graceful failure.
- Perspective correction to a rectangular page.
- Contrast, noise and binarisation enhancement.
- Quality classification (Random Forest vs. rule-based baseline) with confidence scores.
- Skew estimation and human-readable retake suggestions.
- Batch processing of folders, JSON reports, logging, synthetic dataset generator.
- Automated unit and end-to-end tests.
