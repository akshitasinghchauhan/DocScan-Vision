import json
import os

import numpy as np
import pytest

from docscan.classifier import load_model, predict_quality, rule_based_label, train
from docscan.cli import main
from docscan.io_utils import ImageError, load_image, save_image
from docscan.pipeline import process_file


@pytest.fixture(scope="module")
def model_path(tmp_path_factory):
    path = str(tmp_path_factory.mktemp("m") / "model.joblib")
    train(n_per_class=20, seed=1, model_path=path)
    return path


def test_train_beats_chance_and_saves(model_path):
    metrics = json.load(open(os.path.splitext(model_path)[0] + "_metrics.json"))
    assert metrics["random_forest_test_accuracy"] > 0.9
    assert os.path.isfile(model_path)


def test_train_rejects_tiny_sample():
    with pytest.raises(ValueError):
        train(n_per_class=2)


def test_predict_uses_model(model_path, page, rng):
    from docscan.synthetic import degrade
    model = load_model(model_path)
    label, probs = predict_quality(degrade(page, "dark", rng), model)
    assert label == "dark"
    assert abs(sum(probs.values()) - 1) < 0.02


def test_rule_fallback_without_model(page):
    label, _ = predict_quality(page, None)
    assert label == rule_based_label(np.array([8.0, 240.0, 30.0, 0.1]))


def test_load_image_errors(tmp_path):
    with pytest.raises(ImageError):
        load_image(str(tmp_path / "missing.jpg"))
    bad = tmp_path / "bad.jpg"
    bad.write_text("not an image")
    with pytest.raises(ImageError):
        load_image(str(bad))


def test_process_file_writes_outputs(tmp_path, photo_and_corners, model_path):
    photo, _ = photo_and_corners
    src = str(tmp_path / "in.jpg")
    save_image(src, photo)
    report = process_file(src, str(tmp_path / "out"), model=load_model(model_path))
    assert report["document_found"]
    for suffix in ("1_detected.jpg", "2_rectified.png", "3_enhanced.png", "4_scan_bw.png", "report.json"):
        assert os.path.isfile(tmp_path / "out" / f"in_{suffix}")


def test_cli_end_to_end(tmp_path):
    demo = str(tmp_path / "demo")
    out = str(tmp_path / "out")
    log = str(tmp_path / "t.log")
    assert main(["--log-file", log, "demo", "--out", demo, "--count", "4"]) == 0
    assert main(["--log-file", log, "scan", "--input", demo, "--output", out, "--no-model"]) == 0
    assert main(["--log-file", log, "scan", "--input", str(tmp_path / "nope.jpg"), "--output", out]) == 1
