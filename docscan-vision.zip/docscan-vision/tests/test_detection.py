import numpy as np

from docscan.detection import find_document_corners, order_points
from docscan.transform import four_point_transform


def test_order_points_returns_tl_tr_br_bl():
    pts = np.array([[100, 100], [0, 0], [0, 100], [100, 0]], dtype="float32")
    out = order_points(pts)
    assert out.tolist() == [[0, 0], [100, 0], [100, 100], [0, 100]]


def test_corners_close_to_ground_truth(photo_and_corners):
    photo, truth = photo_and_corners
    corners, found = find_document_corners(photo)
    assert found
    err = np.linalg.norm(order_points(truth) - corners, axis=1)
    assert err.max() < 25  # pixels on a 1100x1400 image


def test_fallback_when_no_document():
    blank = np.full((400, 400, 3), 128, dtype=np.uint8)
    corners, found = find_document_corners(blank)
    assert not found
    assert corners.shape == (4, 2)


def test_perspective_output_is_upright_rectangle(photo_and_corners):
    photo, _ = photo_and_corners
    corners, _ = find_document_corners(photo)
    warped = four_point_transform(photo, corners)
    h, w = warped.shape[:2]
    assert h > w > 300  # portrait page recovered
    assert warped.mean() > 180  # mostly white page, no desk left over
