import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from docscan.synthetic import make_page, make_photo  # noqa: E402


@pytest.fixture
def rng():
    return np.random.default_rng(123)


@pytest.fixture
def page(rng):
    return make_page(rng)


@pytest.fixture
def photo_and_corners(rng, page):
    return make_photo(rng, page)
