import numpy as np
import pytest

from docscan.quality import estimate_skew, extract_features
from docscan.synthetic import degrade
import cv2


def test_blur_lowers_sharpness(page, rng):
    sharp = extract_features(page)["sharpness"]
    blurred = extract_features(degrade(page, "blurry", rng))["sharpness"]
    assert blurred < sharp


def test_dark_lowers_brightness(page, rng):
    assert extract_features(degrade(page, "dark", rng))["brightness"] < extract_features(page)["brightness"]


def test_low_contrast_lowers_std(page, rng):
    assert extract_features(degrade(page, "low_contrast", rng))["contrast"] < extract_features(page)["contrast"]


def test_skew_near_zero_for_flat_page(page):
    assert abs(estimate_skew(page)) < 1.0


def test_skew_detects_rotation(page):
    h, w = page.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2, h / 2), 8, 1.0)
    rotated = cv2.warpAffine(page, m, (w, h), borderValue=(255, 255, 255))
    assert 4 < abs(estimate_skew(rotated)) < 12


def test_unknown_label_raises(page, rng):
    with pytest.raises(ValueError):
        degrade(page, "nonsense", rng)
